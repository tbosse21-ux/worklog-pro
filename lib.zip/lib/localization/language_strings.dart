abstract class LanguageStrings {
  String get appName;

  String get dashboard;

  String get reports;

  String get customers;

  String get settings;

  String get newWorkReport;

  String get customer;

  String get constructionSite;

  String get activity;

  String get save;

  String get welcome;

  String get delete;

  String get newReportSubtitle;

  String get reportsSubtitle;

  String get customersSubtitle;

  String get settingsSubtitle;

  String get companyData;

  String get companyName;

  String get contactPerson;

  String get street;

  String get zipCode;

  String get city;

  String get phone;

  String get mobile;

  String get email;

  String get website;

  String get companySaved;

  String get editCompanyData;

  String get companyLogo;

  String get selectLogo;

  String get pdfTitle;

  String get date;

  String get start;

  String get end;

  String get breakTime;

  String get total;

  String get workingTime;

  String get employee;

  String get materials;

  String get signatures;

  String get customerSignature;

  String get employeeSignature;

  String get quantity;

  String get remark;

  String get noMaterials;

  String get createdWith;
  String get material;

  String get materialSubtitle;

  String get newMaterial;

  String get importMaterial;
  String get reportsTitle;

  String get newReport;

  String get searchReports;

  String get noReportsFound;

  String get unknownCustomer;
  
  String get unit;

}
