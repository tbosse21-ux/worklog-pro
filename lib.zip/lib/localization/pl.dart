import 'language_strings.dart';

class PolishStrings extends LanguageStrings {
  @override
  String get appName => "WorkLog Pro";

  @override
  String get dashboard => "Start";

  @override
  String get reports => "Raporty";

  @override
  String get customers => "Klienci";

  @override
  String get settings => "Ustawienia";

  @override
  String get newWorkReport => "Nowy raport pracy";

  @override
  String get customer => "Klient";

  @override
  String get constructionSite => "Budowa";

  @override
  String get newReportSubtitle => "Utwórz nowy raport";

  @override
  String get reportsSubtitle => "Przeglądaj raporty";

  @override
  String get customersSubtitle => "Zarządzaj klientami";

  @override
  String get settingsSubtitle => "Język i ustawienia";

  @override
  String get activity => "Czynność";

  @override
  String get save => "Zapisz";

  @override
  String get welcome => "Witamy";

  @override
  String get delete => "Usuń";

  @override
  String get companyData => "Dane firmy";

  @override
  String get companyName => "Nazwa firmy";

  @override
  String get contactPerson => "Osoba kontaktowa";

  @override
  String get street => "Ulica";

  @override
  String get zipCode => "Kod pocztowy";

  @override
  String get city => "Miasto";

  @override
  String get phone => "Telefon";

  @override
  String get mobile => "Telefon komórkowy";

  @override
  String get email => "E-mail";

  @override
  String get website => "Strona internetowa";

  @override
  String get companySaved => "Dane firmy zostały zapisane";

  @override
  String get editCompanyData => "Edytuj dane firmy";

  @override
  String get companyLogo => "Logo firmy";

  @override
  String get selectLogo => "Wybierz logo";

  @override
  String get pdfTitle => "Raport pracy";

  @override
  String get date => "Data";

  @override
  String get start => "Początek";

  @override
  String get end => "Koniec";

  @override
  String get breakTime => "Przerwa";

  @override
  String get total => "Łącznie";

  @override
  String get workingTime => "Czas pracy";

  @override
  String get employee => "Monter";

  @override
  String get materials => "Materiały";

  @override
  String get signatures => "Podpisy";

  @override
  String get customerSignature => "Klient";

  @override
  String get employeeSignature => "Monter";

  @override
  String get quantity => "Ilość";

  @override
  String get remark => "Uwagi";

  @override
  String get noMaterials => "Brak dodanych materiałów";

  @override
  String get createdWith => "Utworzono w WorkLog Pro";
  @override
  String get material => "Materiały";

  @override
  String get materialSubtitle => "Zarządzaj bazą materiałów";

  @override
  String get newMaterial => "Nowy materiał";

  @override
  String get importMaterial => "Importuj materiały";

  @override
  String get reportsTitle => "Raporty pracy";

  @override
  String get newReport => "Nowy raport";

  @override
  String get searchReports => "Szukaj klienta lub budowy";

  @override
  String get noReportsFound => "Nie znaleziono raportów.";

  @override
  String get unknownCustomer => "Nieznany klient";

  @override
  String get unit => "Jednostka";
}
