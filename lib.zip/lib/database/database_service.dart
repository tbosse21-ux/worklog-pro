import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseService {
  static Database? _database;

  static Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await _initDatabase();
    return _database!;
  }

  static Future<Database> _initDatabase() async {
    final path = join(await getDatabasesPath(), 'worklog_pro.db');

    return await openDatabase(
      path,
      version: 6,

      onCreate: (db, version) async {
        // Kunden
        await db.execute('''
          CREATE TABLE customers(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL
          )
        ''');

        // Firma
        await db.execute('''
          CREATE TABLE company(
            id INTEGER PRIMARY KEY,
            companyName TEXT,
            contactPerson TEXT,
            street TEXT,
            zipCode TEXT,
            city TEXT,
            phone TEXT,
            mobile TEXT,
            email TEXT,
            website TEXT,
            logoPath TEXT
          )
        ''');

        // Arbeitsberichte
        await db.execute('''
          CREATE TABLE work_reports(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            customerId INTEGER NOT NULL,
            constructionSite TEXT NOT NULL,
            startTime TEXT NOT NULL,
            endTime TEXT NOT NULL,
            breakMinutes INTEGER NOT NULL,
            activity TEXT NOT NULL,
            FOREIGN KEY(customerId) REFERENCES customers(id)
          )
        ''');

        // Materialstamm
        await db.execute('''
          CREATE TABLE materials(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            articleNumber TEXT,
            unit TEXT NOT NULL,
            category TEXT NOT NULL
          )
        ''');

        // Materialien je Arbeitsbericht
        await db.execute('''
          CREATE TABLE work_report_materials(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reportId INTEGER NOT NULL,
            materialId INTEGER NOT NULL,
            quantity REAL NOT NULL,
            remark TEXT,
            FOREIGN KEY(reportId) REFERENCES work_reports(id),
            FOREIGN KEY(materialId) REFERENCES materials(id)
          )
        ''');
      },

      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 6) {
          await db.execute('DROP TABLE IF EXISTS work_report_materials');
          await db.execute('DROP TABLE IF EXISTS materials');
          await db.execute('DROP TABLE IF EXISTS work_reports');
          await db.execute('DROP TABLE IF EXISTS work_report_days');
          await db.execute('DROP TABLE IF EXISTS company');
          await db.execute('DROP TABLE IF EXISTS customers');

          // Kunden
          await db.execute('''
            CREATE TABLE customers(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT NOT NULL
            )
          ''');

          // Firma
          await db.execute('''
            CREATE TABLE company(
              id INTEGER PRIMARY KEY,
              companyName TEXT,
              contactPerson TEXT,
              street TEXT,
              zipCode TEXT,
              city TEXT,
              phone TEXT,
              mobile TEXT,
              email TEXT,
              website TEXT,
              logoPath TEXT
            )
          ''');

          // Arbeitsberichte
          await db.execute('''
            CREATE TABLE work_reports(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              date TEXT NOT NULL,
              customerId INTEGER NOT NULL,
              constructionSite TEXT NOT NULL,
              startTime TEXT NOT NULL,
              endTime TEXT NOT NULL,
              breakMinutes INTEGER NOT NULL,
              activity TEXT NOT NULL,
              FOREIGN KEY(customerId) REFERENCES customers(id)
            )
          ''');

          // Materialstamm
          await db.execute('''
            CREATE TABLE materials(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT NOT NULL,
              articleNumber TEXT,
              unit TEXT NOT NULL,
              category TEXT NOT NULL
            )
          ''');

          // Materialien je Arbeitsbericht
          await db.execute('''
            CREATE TABLE work_report_materials(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              reportId INTEGER NOT NULL,
              materialId INTEGER NOT NULL,
              quantity REAL NOT NULL,
              remark TEXT,
              FOREIGN KEY(reportId) REFERENCES work_reports(id),
              FOREIGN KEY(materialId) REFERENCES materials(id)
            )
          ''');
        }
      },
    );
  }
}
