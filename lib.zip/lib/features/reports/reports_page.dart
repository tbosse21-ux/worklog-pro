import 'package:flutter/material.dart';

import '../../database/customer_repository.dart';
import '../../database/work_report_repository.dart';
import '../../localization/app_language.dart';
import '../../models/customer.dart';
import '../../models/work_report.dart';
import '../../services/pdf_service.dart';
import '../work_reports/new_work_report_page.dart';

class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key});

  @override
  State<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends State<ReportsPage> {
  final WorkReportRepository _workReportRepository = WorkReportRepository();

  final CustomerRepository _customerRepository = CustomerRepository();

  final TextEditingController _searchController = TextEditingController();

  List<WorkReport> _reports = [];

  final Map<int, Customer> _customers = {};

  String _search = "";

  @override
  void initState() {
    super.initState();
    _loadReports();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadReports() async {
    final reports = await _workReportRepository.getAll();

    reports.sort(
      (a, b) => DateTime.parse(b.date).compareTo(DateTime.parse(a.date)),
    );

    _customers.clear();

    for (final report in reports) {
      final customer = await _customerRepository.getCustomerById(
        report.customerId,
      );

      if (customer != null) {
        _customers[report.customerId] = customer;
      }
    }

    if (!mounted) return;

    setState(() {
      _reports = reports;
    });
  }

  Future<void> _deleteReport(WorkReport report) async {
    final t = AppLanguage.instance.strings;

    final delete =
        await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            title: Text(t.delete),
            content: const Text("Arbeitsbericht wirklich löschen?"),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text("Abbrechen"),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: Text(t.delete),
              ),
            ],
          ),
        ) ??
        false;

    if (!delete) return;

    await _workReportRepository.delete(report.id!);

    _loadReports();
  }

  String _formatDate(String date) {
    final d = DateTime.parse(date);

    return "${d.day.toString().padLeft(2, "0")}."
        "${d.month.toString().padLeft(2, "0")}."
        "${d.year}";
  }

  String _workingTime(WorkReport report) {
    final start = report.startTime.split(":");

    final end = report.endTime.split(":");

    final startMinutes = int.parse(start[0]) * 60 + int.parse(start[1]);

    final endMinutes = int.parse(end[0]) * 60 + int.parse(end[1]);

    final total = endMinutes - startMinutes - report.breakMinutes;

    final hours = total ~/ 60;
    final minutes = total % 60;

    return "$hours Std. ${minutes.toString().padLeft(2, "0")} Min.";
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLanguage.instance.strings;

    final filteredReports = _reports.where((report) {
      if (_search.isEmpty) {
        return true;
      }

      final customer = (_customers[report.customerId]?.name ?? "")
          .toLowerCase();

      return customer.contains(_search) ||
          report.constructionSite.toLowerCase().contains(_search);
    }).toList();
    return Scaffold(
      appBar: AppBar(title: Text(t.reportsTitle)),

      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add),
        label: Text(t.newReport),
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const NewWorkReportPage()),
          );

          _loadReports();
        },
      ),

      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 6),
            child: TextField(
              controller: _searchController,

              decoration: InputDecoration(
                hintText: t.searchReports,

                prefixIcon: const Icon(Icons.search),

                suffixIcon: _search.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();

                          setState(() {
                            _search = "";
                          });
                        },
                      ),

                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),

              onChanged: (value) {
                setState(() {
                  _search = value.toLowerCase();
                });
              },
            ),
          ),

          Expanded(
            child: filteredReports.isEmpty
                ? Center(child: Text(t.noReportsFound))
                : RefreshIndicator(
                    onRefresh: _loadReports,
                    child: ListView.builder(
                      padding: const EdgeInsets.only(bottom: 90),
                      itemCount: filteredReports.length,
                      itemBuilder: (context, index) {
                        final report = filteredReports[index];
                        final customer = _customers[report.customerId];

                        return Card(
                          elevation: 2,
                          margin: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(14),
                            onTap: () async {
                              await Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) =>
                                      NewWorkReportPage(report: report),
                                ),
                              );

                              _loadReports();
                            },
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      const CircleAvatar(
                                        child: Icon(Icons.business),
                                      ),

                                      const SizedBox(width: 12),

                                      Expanded(
                                        child: Text(
                                          customer?.name ?? t.unknownCustomer,
                                          style: const TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                      PopupMenuButton<String>(
                                        onSelected: (value) async {
                                          switch (value) {
                                            case "pdf":
                                              await PdfService.preview(
                                                report.id!,
                                              );
                                              break;
                                            case "share":
                                              await PdfService.sharePdf(
                                                report.id!,
                                              );
                                              break;

                                            case "edit":
                                              await Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                  builder: (_) =>
                                                      NewWorkReportPage(
                                                        report: report,
                                                      ),
                                                ),
                                              );

                                              _loadReports();
                                              break;

                                            case "delete":
                                              await _deleteReport(report);
                                              break;
                                          }
                                        },
                                        itemBuilder: (_) => [
                                          const PopupMenuItem(
                                            value: "pdf",
                                            child: Row(
                                              children: [
                                                Icon(Icons.picture_as_pdf),
                                                SizedBox(width: 10),
                                                Text("PDF anzeigen"),
                                              ],
                                            ),
                                          ),

                                          const PopupMenuItem(
                                            value: "share",
                                            child: Row(
                                              children: [
                                                Icon(Icons.share),
                                                SizedBox(width: 10),
                                                Text("PDF teilen"),
                                              ],
                                            ),
                                          ),
                                          const PopupMenuItem(
                                            value: "edit",
                                            child: Row(
                                              children: [
                                                Icon(Icons.edit),
                                                SizedBox(width: 10),
                                                Text("Bearbeiten"),
                                              ],
                                            ),
                                          ),
                                          PopupMenuItem(
                                            value: "delete",
                                            child: Row(
                                              children: [
                                                const Icon(
                                                  Icons.delete,
                                                  color: Colors.red,
                                                ),
                                                const SizedBox(width: 10),
                                                Text(
                                                  t.delete,
                                                  style: const TextStyle(
                                                    color: Colors.red,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),

                                  const SizedBox(height: 16),

                                  Row(
                                    children: [
                                      const Icon(
                                        Icons.calendar_today,
                                        size: 18,
                                      ),
                                      const SizedBox(width: 8),
                                      Text(_formatDate(report.date)),
                                    ],
                                  ),

                                  const SizedBox(height: 8),

                                  Row(
                                    children: [
                                      const Icon(Icons.location_on, size: 18),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: Text(report.constructionSite),
                                      ),
                                    ],
                                  ),

                                  const SizedBox(height: 12),

                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 12,
                                      vertical: 8,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Theme.of(
                                        context,
                                      ).colorScheme.primaryContainer,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Row(
                                      children: [
                                        const Icon(Icons.schedule),
                                        const SizedBox(width: 8),
                                        Text(
                                          _workingTime(report),
                                          style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
